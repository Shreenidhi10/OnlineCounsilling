-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2022 at 11:50 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jeca`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`email`, `password`) VALUES
('shreyagowda237@gmail.com', 'shreya'),
('sindhuramesh121@gmail.com', 'sindhu');

-- --------------------------------------------------------

--
-- Table structure for table `councellingcities`
--

CREATE TABLE `councellingcities` (
  `cityid` int(15) NOT NULL,
  `district` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `councellingcities`
--

INSERT INTO `councellingcities` (`cityid`, `district`, `city`) VALUES
(21, 'Udupi', 'MELUR'),
(22, 'Udupi', 'Kanithhalli'),
(23, 'Banglore', 'Devanahalli'),
(24, 'Banglore', 'Doddaballapura');

-- --------------------------------------------------------

--
-- Table structure for table `councellingstudents`
--

CREATE TABLE `councellingstudents` (
  `applicationid` int(10) NOT NULL,
  `rollno` int(50) NOT NULL,
  `candidatename` varchar(50) NOT NULL,
  `fathername` varchar(50) NOT NULL,
  `mothername` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `rank` int(50) NOT NULL,
  `institute` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `aadhar` varchar(250) NOT NULL,
  `address` varchar(50) NOT NULL,
  `locality` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `pincode` int(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `sign` varchar(100) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `chalan` varchar(50) NOT NULL,
  `payername` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `councellingstudents`
--

INSERT INTO `councellingstudents` (`applicationid`, `rollno`, `candidatename`, `fathername`, `mothername`, `dob`, `rank`, `institute`, `gender`, `aadhar`, `address`, `locality`, `city`, `state`, `district`, `pincode`, `email`, `mobile`, `photo`, `sign`, `bank`, `chalan`, `payername`) VALUES
(202210015, 92603404, 'Likhith R', 'Rajanna B', 'Shantha B R', '1992-05-24', 1, 'VTU', 'male', '1234 5678 9101', 'Bijjawara', '', 'Bangalore', '2', '8', 562110, 'likith98524@gmail.com', '9233232323', '', '', 'Bank of Baroda', 'Aw12222', 'ads sda'),
(202210016, 92601114, 'Monish', 'Ayush ', 'Reema ', '1992-12-04', 50, 'BNU', 'male', '1122 3333 4444', 'Hebbal', '', 'Blore rural', '2', '8', 221222, 'monish287@gmail.com', '9123456780', '', '', 'Bank of Baroda', 'Aw22211', 'sdads'),
(202210017, 92605393, 'Sindhu', 'Ramesh', 'Mamatha', '1990-12-29', 62, 'Reva university', 'female', '9876 5432 1099', 'Kanathalli', '', 'cbpura', '3', '27', 312322, 'sindhu121@gmail.com', '9088365980', '', '', 'Bank of Maharashtra', 'Qr43435', 'Adsdsa'),
(202210018, 92603128, 'Shreya', 'Suresh', 'Smitha', '1993-04-04', 89, 'Nitte', 'female', '9999 9999 9999', 'Melur', '', 'sdlagata', '2', '5', 562102, 'shreya237@gmail.com', '9212124230', '', '', 'Bank of Baroda', 'Uy90909', 'cvb'),
(202210023, 92604249, 'Harshitha', 'Srinivas', 'Kavitha', '1992-07-31', 100, 'Nagarjuna college of Engineering', 'female', '1234 5678 9133', 'Jallilali cross', '', 'Bangalore', '18', '5', 562199, 'harshi@gmail.com', '9546728194', '', '', 'Oriental Bank of Commerce', 'Aa34516', 'Harshitha');

-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE `counter` (
  `ID` int(10) NOT NULL,
  `COUNTER` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `counter`
--

INSERT INTO `counter` (`ID`, `COUNTER`) VALUES
(1, 14);

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `districtid` int(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `stateid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`districtid`, `district`, `stateid`) VALUES
(1, 'Bagalkot', 18),
(2, 'Ballari (Bellary)', 18),
(3, 'Belagavi (Belgaum)', 18),
(4, 'Bengaluru (Bangalore) Rural', 18),
(5, 'Bengaluru (Bangalore) Urban', 18),
(6, 'Bidar', 18),
(7, 'Chamarajanagar', 18),
(8, 'Chikballapur', 18),
(9, 'Chikkamagaluru (Chikmagalur)', 18),
(10, 'Chitradurga', 18),
(11, 'Dakshina Kannada', 18),
(12, 'Davangere', 18),
(13, 'Dharwad', 18),
(14, 'Gadag', 18),
(15, 'Hassan', 18),
(16, 'Haveri', 18),
(17, 'Kalaburagi (Gulbarga)', 18),
(18, 'Kodagu', 18),
(19, 'Kolar', 18),
(20, 'Koppal', 18),
(21, 'Mandya', 18),
(22, 'Mysuru (Mysore)', 18),
(23, 'Raichur', 18),
(24, 'Ramanagara', 18),
(25, 'Shivamogga (Shimoga)', 18);

-- --------------------------------------------------------

--
-- Table structure for table `examdistrict`
--

CREATE TABLE `examdistrict` (
  `DistrictID` int(11) NOT NULL,
  `ExamDistrict` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examdistrict`
--

INSERT INTO `examdistrict` (`DistrictID`, `ExamDistrict`) VALUES
(123, 'Banglore'),
(122, 'Udupi');

-- --------------------------------------------------------

--
-- Table structure for table `meritlist`
--

CREATE TABLE `meritlist` (
  `meritid` int(50) NOT NULL,
  `rollno` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `cat` varchar(50) NOT NULL,
  `pc` varchar(50) NOT NULL,
  `gmr` int(50) NOT NULL,
  `scrank` int(50) DEFAULT NULL,
  `strank` int(50) DEFAULT NULL,
  `pcrank` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meritlist`
--

INSERT INTO `meritlist` (`meritid`, `rollno`, `name`, `dob`, `gender`, `cat`, `pc`, `gmr`, `scrank`, `strank`, `pcrank`) VALUES
(49, 92603404, 'Likhith ', '1992-09-12', 'male', 'general', 'no', 1, 0, 0, 0),
(50, 92601114, 'Monish', '1992-04-13', 'male', 'sc', 'no', 50, 1, 0, 0),
(51, 92605393, 'Sindhu', '1990-12-29', 'female', 'general', 'no', 62, 0, 0, 0),
(52, 92603128, 'Shreya', '1993-04-04', 'female', 'general', 'no', 89, 4, 0, 0),
(53, 92604249, 'Harshitha', '1992-07-31', 'female', 'general', 'no', 100, 0, 0, 0),
(54, 92603444, 'Bindhu', '1992-02-04', 'female', 'obc', 'no', 116, 0, 1, 0),
(55, 92601146, 'Chaitra', '1991-04-20', 'female', 'general', 'no', 147, 0, 0, 0),
(56, 92401360, 'Rakshitha', '1990-08-10', 'female', 'general', 'no', 153, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `participatingcollege`
--

CREATE TABLE `participatingcollege` (
  `collegeid` int(50) NOT NULL,
  `collegename` varchar(50) NOT NULL,
  `openingrank` int(10) NOT NULL,
  `closingrank` int(10) NOT NULL,
  `website` varchar(2090) NOT NULL,
  `seats` int(11) DEFAULT 60
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `participatingcollege`
--

INSERT INTO `participatingcollege` (`collegeid`, `collegename`, `openingrank`, `closingrank`, `website`, `seats`) VALUES
(32, 'Reva university', 1, 89, 'https://www.reva.ac.in/', 59),
(33, 'Banglore north University', 1, 61, 'http://www.bnu.edu.in/', 58),
(34, 'Nitte', 20, 181, 'https://nittecollege.ac.in/', 59),
(35, 'Banglore central University', 82, 455, 'http://www.bcu.ac.in/', 59),
(36, 'Nagarjuna college of Engineering', 62, 264, 'https://www.nce.edu.in/', 57),
(37, 'Sir M.Visvesvaraya Institute of Technology', 159, 548, 'http://www.smvit.edu/', 60),
(38, 'BMSIT', 306, 1000, 'http://www.bmsitcollege.ac.in/', 59),
(39, 'RV COLLEGE', 314, 605, 'http://www.rvuniv.ac.in/', 60),
(40, 'BIT', 1, 1000, 'https://www.bit.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sclist`
--

CREATE TABLE `sclist` (
  `scid` int(50) NOT NULL,
  `rollno` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `cat` varchar(50) NOT NULL,
  `pc` varchar(50) NOT NULL,
  `gmr` int(50) NOT NULL,
  `scrank` int(50) NOT NULL,
  `pcrank` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sessionid`
--

CREATE TABLE `sessionid` (
  `sessionid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `stateid` int(50) NOT NULL,
  `state` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`stateid`, `state`) VALUES
(1, 'ANDAMAN AND NICOBAR ISLANDS'),
(2, 'ANDHRA PRADESH'),
(3, 'ARUNACHAL PRADESH'),
(4, 'ASSAM'),
(5, 'BIHAR'),
(6, 'CHATTISGARH'),
(7, 'CHANDIGARH'),
(8, 'DAMAN AND DIU'),
(9, 'DELHI'),
(10, 'DADRA AND NAGAR HAVELI'),
(11, 'GOA'),
(12, 'GUJARAT'),
(13, 'HIMACHAL PRADESH'),
(14, 'HARYANA'),
(15, 'JAMMU AND KASHMIR'),
(16, 'JHARKHAND'),
(17, 'KERALA'),
(18, 'KARNATAKA'),
(19, 'LAKSHADWEEP'),
(20, 'MEGHALAYA'),
(21, 'MAHARASHTRA'),
(22, 'MANIPUR'),
(23, 'MADHYA PRADESH'),
(24, 'MIZORAM'),
(25, 'NAGALAND'),
(26, 'ORISSA'),
(27, 'PUNJAB'),
(28, 'PONDICHERRY'),
(29, 'RAJASTHAN'),
(30, 'SIKKIM'),
(31, 'TAMIL NADU'),
(32, 'TRIPURA'),
(33, 'UTTARAKHAND'),
(34, 'UTTAR PRADESH'),
(35, 'Karnataka'),
(36, 'TELANGANA'),
(37, '');

-- --------------------------------------------------------

--
-- Table structure for table `stlist`
--

CREATE TABLE `stlist` (
  `stid` int(50) NOT NULL,
  `rollno` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `cat` varchar(50) NOT NULL,
  `pc` varchar(50) NOT NULL,
  `gmr` int(50) NOT NULL,
  `strank` int(50) NOT NULL,
  `pcrank` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_token`
--

CREATE TABLE `user_token` (
  `email` varchar(80) NOT NULL,
  `token` varchar(80) NOT NULL,
  `timemodified` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `councellingcities`
--
ALTER TABLE `councellingcities`
  ADD PRIMARY KEY (`cityid`),
  ADD UNIQUE KEY `city` (`city`),
  ADD KEY `district_fk` (`district`);

--
-- Indexes for table `councellingstudents`
--
ALTER TABLE `councellingstudents`
  ADD PRIMARY KEY (`applicationid`),
  ADD KEY `rollno` (`rollno`),
  ADD KEY `fk2` (`institute`),
  ADD KEY `fk3` (`candidatename`),
  ADD KEY `fk4` (`rank`);

--
-- Indexes for table `counter`
--
ALTER TABLE `counter`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`districtid`),
  ADD KEY `stateid` (`stateid`);

--
-- Indexes for table `examdistrict`
--
ALTER TABLE `examdistrict`
  ADD PRIMARY KEY (`DistrictID`),
  ADD UNIQUE KEY `ExamDistrict_2` (`ExamDistrict`),
  ADD KEY `ExamDistrict` (`ExamDistrict`);

--
-- Indexes for table `meritlist`
--
ALTER TABLE `meritlist`
  ADD PRIMARY KEY (`meritid`),
  ADD UNIQUE KEY `rollno_2` (`rollno`),
  ADD KEY `rollno` (`rollno`),
  ADD KEY `rollno_3` (`rollno`),
  ADD KEY `name` (`name`),
  ADD KEY `gmr` (`gmr`),
  ADD KEY `gmr_2` (`gmr`);

--
-- Indexes for table `participatingcollege`
--
ALTER TABLE `participatingcollege`
  ADD PRIMARY KEY (`collegeid`),
  ADD KEY `collegename` (`collegename`);

--
-- Indexes for table `sclist`
--
ALTER TABLE `sclist`
  ADD PRIMARY KEY (`scid`),
  ADD KEY `rollno_fk` (`rollno`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`stateid`);

--
-- Indexes for table `stlist`
--
ALTER TABLE `stlist`
  ADD PRIMARY KEY (`stid`),
  ADD KEY `rollno_fk2` (`rollno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `councellingcities`
--
ALTER TABLE `councellingcities`
  MODIFY `cityid` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `councellingstudents`
--
ALTER TABLE `councellingstudents`
  MODIFY `applicationid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202210024;

--
-- AUTO_INCREMENT for table `counter`
--
ALTER TABLE `counter`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `districtid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `examdistrict`
--
ALTER TABLE `examdistrict`
  MODIFY `DistrictID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `meritlist`
--
ALTER TABLE `meritlist`
  MODIFY `meritid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `participatingcollege`
--
ALTER TABLE `participatingcollege`
  MODIFY `collegeid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `sclist`
--
ALTER TABLE `sclist`
  MODIFY `scid` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `stateid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `stlist`
--
ALTER TABLE `stlist`
  MODIFY `stid` int(50) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
